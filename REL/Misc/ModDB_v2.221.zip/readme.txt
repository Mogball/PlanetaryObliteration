If you insist on installing manually:

Navigate to %localappdata%\uber entertainment\planetary annihilation\. Extract the "com.stuart98.gat.client" folder to either the mods folder or the client_mods folder (depending on your install). Extract the "com.stuart98.gatitans" folder to your server_mods folder. Then change the block of code inside of the mods.json in the mods/client_mods folder to { "mount_order": [ "com.stuart98.gat.client" ] }
And the block of code for the mods.json inside of server_mods to { "mount_order": [ "com.stuart98.gatitans" ] }

After doing all of the above steps, launch the game and start a skirmish or multiplayer game as normal. Just wait for Galactic Annihilation to show up in the bottom left before changing the map and you're good to go.

Please, use PAMM in the future. Not only is it faster and offering automatic updates, but it also allows you to download the entirety of the released mods by the Planetary Annihilation Mod Community.